<template>
  <div>
    <header v-if="count==0" />
    
        <h1>I am headre 1</h1>
    <footer/>
  </div>
</template>

<script>
import header from "@pages/Test/header"
import footer from "@pages/Test/footer"
import page1 from "@pages/Test/page1"
import page2 from "@pages/Test/page2"

export default {
    components:{
        header,footer, page1, page2
    },
    data(){
        return {
            count:0
        }
    },
    created(){
        this.$on("decrement", (data) => {
            count=data
        })
         this.$on("incremented", (data) => {
            count=data
        })
    }
}
</script>

<style>

</style>