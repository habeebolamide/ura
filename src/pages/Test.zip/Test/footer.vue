<template>
  <div>
   <button @click="decrincrement">Prev</button>
   <button @click="increment">Next</button>
  </div>
</template>

<script>


export default {
    
    data(){
        return {
            count:0
        }
    },
    methods:{
        decrincrement(){
            if(this.count !=0) {
                this.count--
                this.$emit('decrement', this.count)

            }
        },
        increment(){
            if(this.count <=12) {
                this.count++
                this.$emit('incremented', this.count)

            }
        }
    }
}
</script>

<style>

</style>